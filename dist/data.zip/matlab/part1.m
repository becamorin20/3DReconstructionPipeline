%addpath('../../TOOLBOX_calib/')
%calib_gui
%28 mm
%got calib_data.mat for left camera
%got calib data for right camera
%got stereo calib data

%need to convert om and t to rotation matrix
%R = rodrigues(om)
