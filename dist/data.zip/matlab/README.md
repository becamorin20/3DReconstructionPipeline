# CS117Final-Project
3D reconstruction pipeline
Using Matlab

If your are planning on running the entire pipeline, please make sure you have downloaded the teapot and calibration images and put them in the appropriate places. (refrence final report for folder structure)

In its current state, the necessary .mat files have already been included that have the generated reconstructions and meshes.

Please also refer to diaz_pipeline.m for the code blocks necesarry to rebuild those .mat files

and demoscript.mat for generating the ply files.

Please also note, that you will need to alter the file paths in demoscript,diaz_reconstruct, diaz_pipeline, and diaz_mesh if you are regenerating the ply or mat files.

aka line 12 of demoscript at the least

Also note i had to delete the reconstructions (the .mat files so i could upload to eee)